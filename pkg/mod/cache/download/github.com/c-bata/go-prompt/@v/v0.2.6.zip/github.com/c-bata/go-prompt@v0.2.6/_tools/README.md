## Tools of go-prompt

### vt100_debug

![vt100_debug](https://github.com/c-bata/assets/raw/master/go-prompt/tools/vt100_debug.gif)

### sigwinch

![sigwinch](https://github.com/c-bata/assets/raw/master/go-prompt/tools/sigwinch.gif)

