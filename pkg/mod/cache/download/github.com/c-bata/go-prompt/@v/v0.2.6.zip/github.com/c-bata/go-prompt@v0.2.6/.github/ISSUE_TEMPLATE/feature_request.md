---
name: "Feature request"
about: Suggest an idea for new features in go-prompt.
title: "[Feature Request]"
labels: enhancement
assignees: ''

---

# Feature Request

*Please write your suggestion here.*

